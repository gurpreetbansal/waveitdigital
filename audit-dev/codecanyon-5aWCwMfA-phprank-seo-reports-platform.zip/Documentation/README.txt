Installation documentation is available at:
https://lunatio.com/phprank/documentation